<?php
require_once 'includes/auth.php';
requireLogin();

$user = currentUser();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Morismetal</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container">
        <?php include 'includes/sidebar.php'; ?>
        
        <main class="content">
            <h1>Bienvenido, <?= htmlspecialchars($user['nombre']) ?></h1>
            
            <div class="dashboard-cards">
                <div class="card">
                    <h3>Recepciones Hoy</h3>
                    <p class="big-number">5</p>
                    <a href="modules/recepcion/" class="btn-link">Ver todas</a>
                </div>
                
                <div class="card">
                    <h3>Órdenes en Proceso</h3>
                    <p class="big-number">12</p>
                    <a href="modules/taller/" class="btn-link">Ver todas</a>
                </div>
                
                <div class="card">
                    <h3>Cotizaciones Pendientes</h3>
                    <p class="big-number">3</p>
                    <a href="modules/cotizaciones/" class="btn-link">Ver todas</a>
                </div>
                
                <div class="card">
                    <h3>Ingresos del Mes</h3>
                    <p class="big-number">$4,250,000</p>
                    <a href="modules/reportes/" class="btn-link">Ver reporte</a>
                </div>
            </div>
            
            <div class="recent-activity">
                <h2>Actividad Reciente</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Descripción</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>2023-11-15 14:30</td>
                            <td>Recepción</td>
                            <td>Camioneta Ford Ranger</td>
                            <td>Juan Pérez</td>
                        </tr>
                        <tr>
                            <td>2023-11-15 13:45</td>
                            <td>Factura</td>
                            <td>Factura #1234 emitida</td>
                            <td>María González</td>
                        </tr>
                        <tr>
                            <td>2023-11-15 11:20</td>
                            <td>Compra</td>
                            <td>Materiales comprados a Proveedor XYZ</td>
                            <td>Carlos López</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>